#!/bin/bash
export PATH=$PATH:/var/task/node_modules/.bin:/opt/nodejs/node_modules/.bin
npm config set cache /tmp/.npm
echo starting server
next start